#mosaic

马赛克拼图Matlab版本

本项目参考自Daniel Claxton[^1]，仅供学习研究，请勿用于商业用途

[^1]: http://nl.mathworks.com/matlabcentral/fileexchange/7876-mosaic

---
###简介

本程序将照片马赛克化，并使用瓦片图进行拼接后叠加到原始图片上

[](http://images.cnblogs.com/cnblogs_com/li12242/775762/o_Autumn.jpg)

---
###使用说明

适用于 Linux/Mac Matlab R2014b 及以上版本

---
###版本信息

####ver1.0

修改Daniel原始程序

1. 删除GUI
2. 优化瓦片图拼接过程